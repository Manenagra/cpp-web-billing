#ifndef FUNCTION_H
#define FUNCTION_H

void readAndCheck(int account_number, double start_disk_usage, double &max_disk_usage, double &end_disk_used, char &valid, bool &error);

bool isValidAccountNumber(int account_number);

void calculateBill(double base_charge, double disk_limit, double max_disk_usage, double end_disk_used, double &over_limit_surcharge, double &end_surcharge, double &GST_owed, double &total_owed);

void printBill(int account_number, double base_charge, double disk_limit, double start_disk_usage, double max_disk_usage, double end_disk_used, double over_limit_surcharge, double end_surcharge, double GST_owed, double total_owed);

#endif
