#include "function.h"
#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;

void readAndCheck(int account_number, double start_disk_usage, double &max_disk_usage, double &end_disk_used, char &valid, bool &error){
   /*
    Read the account number and check the account number and valid flag.
    If it is valid flag and account is valid than it reads the second line in the monthly transaction. Then update the max disk usage and end of month disk usage with the input.
    If it isn't valid than it prints error massage and updates the error flage.
   */
  cin>>max_disk_usage>>end_disk_used>>valid;
  
  if(!isValidAccountNumber(account_number)){
    cout<<"Invalid account number "<<account_number<<" found"<<endl;
    error=true;
  }
  if(valid=='F'){
    cout<<"Bad monthly transaction record"<<endl;
    error=true;
  }
}

bool isValidAccountNumber(int account_number){
  /*
    This function checks if the account is valid by checking if it consists of 6 digits and that the leftmost digits equals the units digit of the sumof the other digits, each multiplied by its position.
   */
  //initialize variables
  int count=0;
  int sum=0;
  int first_digit=0;

  while (account_number>0){
    int digit=account_number%10;//gives the last digit
    count++;
    if(count==6){
      first_digit=digit;//saving the left digit
    }else{
      sum+=(digit*count);//multiplying digit by position
    }
    account_number /=10;//removes the last digit
  }
  return (count==6 && (sum%10==first_digit));
}

void calculateBill(double base_charge, double disk_limit, double max_disk_usage, double end_disk_used, double &over_limit_surcharge, double &end_surcharge, double &GST_owed, double &total_owed){
  /*
    Calculates the bill for the transaction by calculating the over limit surcharge, end surcharge, GST owed, and total owed.
   */
  double over_limit= max_disk_usage-disk_limit;
  
  if(over_limit<0){
    over_limit_surcharge=0;
  }
  else if(over_limit<=50.0){
    over_limit_surcharge=over_limit*0.15;
  }
  else if(50.0<over_limit && over_limit<=250){
    over_limit_surcharge=50*0.15;
    over_limit-=50;
    over_limit_surcharge+=over_limit*0.26;
  }
  else if(over_limit>250 && over_limit<=500){
    over_limit_surcharge=(50*0.15)+(200*0.26);
    over_limit-=250;
    over_limit_surcharge+=over_limit*0.37;
  }
  else{
    over_limit_surcharge=(50*0.15)+(200*0.26)+(250*0.37);
    over_limit-=500;
    over_limit_surcharge+=over_limit*0.48;
  }

  double over_end_limit= end_disk_used-disk_limit;

  if(over_end_limit>0){
    end_surcharge=over_end_limit*0.05;

    if(end_surcharge<5){
      end_surcharge=5;
    }
  }
  else{
    end_surcharge=0;
  }

  GST_owed=((base_charge+over_limit_surcharge+end_surcharge)*0.05);

  total_owed=base_charge+over_limit_surcharge+end_surcharge+GST_owed;
}

void printBill(int account_number, double base_charge, double disk_limit, double start_disk_usage, double max_disk_usage, double end_disk_used, double over_limit_surcharge, double end_surcharge, double GST_owed, double total_owed){
  /*
    Prints the bill using the values and the disk values are three decimal places while the dollar values are two decimal places. The surcharge is only printed when applied.
   */
  int width=25;//the width space given to a value

  cout<<fixed<<setprecision(3)<<left;
  //setting every following value to three digits and left aligned.

  cout<<setw(width)<<"Account Number: "<<account_number<<endl;
  cout<<setw(width)<<"Disk Allotment: "<<disk_limit<<" MB"<<endl;
  cout<<setw(width)<<"Beginning of Month: "<<start_disk_usage<<" MB"<<endl;
  cout<<setw(width)<<"Maximum during Month: "<<max_disk_usage<<" MB"<<endl;
  cout<<setw(width)<<"End of Month: "<<end_disk_used<<" MB"<<endl;

  cout<<fixed<<setprecision(2)<<left;
  //setting the dollar values to two decimal places and left aligned

  cout<<setw(width-1)<<"Base Charge: "<<setw(3)<<"$"<<base_charge<<endl;

  if (over_limit_surcharge > 0){
    cout<<setw(width-1)<<"Over-limit Surcharge: "<<setw(3)<<"$"<<over_limit_surcharge<<endl;
  }
  if (end_surcharge > 0) {
    cout<<setw(width-1)<<"Surcharge: "<<setw(3)<<"$"<<end_surcharge<<endl;
  }

  cout<<setw(width-1)<<"GST: "<<setw(3)<<"$"<<GST_owed<<endl;
  cout<<setw(width-1)<<"Amount Due: "<<setw(3)<<"$"<<total_owed<<endl;
}
