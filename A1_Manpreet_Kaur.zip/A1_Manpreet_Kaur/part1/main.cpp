#include "function.h"
#include <iostream>
using namespace std;

int main(){
  /*
    This function reads the monthly transaction and reads the header record and calls the readAndCheck function to determine the validity of the accounts and if not valid it detects errors and prints error massages. If valid it calls the calculateBill and printBill functions to display the bill with the calculated values.
   */
  //Initialize variables
  int account_number;
  double base_charge;
  double disk_limit;
  double start_disk_usage;
  double max_disk_usage;
  double end_disk_used;
  char valid;
  double over_limit_surcharge;
  double end_surcharge;
  double GST_owed;
  double total_owed;
  bool error=false;
  
  cin>>account_number>>base_charge>>disk_limit>>start_disk_usage;

  readAndCheck(account_number, start_disk_usage, max_disk_usage, end_disk_used, valid, error);

  if(error){
    cout<<"*** Account "<<account_number<<" not processed due to errors ***"<<endl;
  }
  else{
    calculateBill(base_charge,disk_limit,max_disk_usage,end_disk_used,over_limit_surcharge, end_surcharge, GST_owed, total_owed);

    printBill(account_number,base_charge,disk_limit,start_disk_usage,max_disk_usage,end_disk_used,over_limit_surcharge,end_surcharge,GST_owed,total_owed);}
}
