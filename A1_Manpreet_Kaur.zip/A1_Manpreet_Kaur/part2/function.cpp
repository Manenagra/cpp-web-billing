#include "function.h"
#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;

void readAndProcess(int account_number, double start_disk_usage, double &max_disk_usage, double &end_disk_used, bool &valid, int &error, int &line){
  /*
    Read account numbers and check if they are valid. 
    If they are valid than call readAndTotal function to calculate end of month and maximum usage. 
    If they aren't valid than call readAndIgnore to read the transaction record and track the line number that its on.
   */
  
  if(isValidAccountNumber(account_number)){

    readAndTotal(account_number,start_disk_usage, max_disk_usage, end_disk_used, valid, line, error);

  }else{

    cout<<"Error in line #"<<line<<" - - invalid account number "<<account_number<<endl;//prints error since the account in invalid

    error++;

    valid=false;//since the account isn't valid the bill won't be calculated nor printed
    readAndIgnore(line);
  }
}

void readAndTotal(int account_number, double start_disk_usage, double &max_disk_usage, double &end_disk_used, bool &valid, int &line, int &error){
  /*
    Reads the transaction record until the sentinel (-1 X -1) is read. It updates the current, maximum and end-of-month disk usage by adding or subtracting based on the code and the values passed into the input.
   */

  int transaction_account;
  char transaction_code;
  double amount_disk_change;
  double current_disk_usage=start_disk_usage;
  
  max_disk_usage=start_disk_usage;

  valid=true;
  
  cin>>transaction_account>>transaction_code>>amount_disk_change;

  line++;
  // The following while loop will read until the sentinel value is reached.
  while(!cin.eof()&&(transaction_account!=-1 || transaction_code!='X' || amount_disk_change!=-1)){

    if(transaction_account!=account_number){
      //if the transaction account number dosn't match the header account number than an error is printed 
      cout<<"Error in line "<<line<<" - non-matching account number "<<transaction_account<<endl;
      error++;
      valid=false;//this account won't be printed
    }

    if(amount_disk_change<0){
      //amount disk change can't be negetive. This is checking for invalid negetive transaction amount 
      cout<<"Error in line "<<line<<" - negative transaction amount "<<amount_disk_change<<endl;
      error++;
      valid=false;
    }

    if(transaction_code!='C' && transaction_code!='D'){
      //checking for invalid code 
      cout<<"Error in line "<<line<<" - invalid transaction code "<<transaction_code<<endl;
      error++;
      valid=false;
    }

    if(amount_disk_change>=0 && (transaction_code=='C' || transaction_code=='D')&&(transaction_account==account_number)){

      if (transaction_code=='C'){
	current_disk_usage+=amount_disk_change;
      }else if(transaction_code=='D'){
	current_disk_usage-=amount_disk_change;
      }
      if(current_disk_usage>max_disk_usage){
	max_disk_usage=current_disk_usage;
      }

    }

    cin>>transaction_account>>transaction_code>>amount_disk_change;
    line++;

  }

  end_disk_used=current_disk_usage;
}

void readAndIgnore(int &line){
  /*
    When the account number is invalid this function will read the transaction recod until it reached the sentinel value of (-1 X -1) and it will update the line number its reading from.
   */
  int transaction_account;
  char transaction_code;
  double amount_disk_change;

  cin>>transaction_account>>transaction_code>>amount_disk_change;
  line++;
  
  while(transaction_account!=-1 || transaction_code!='X' || amount_disk_change!=-1){
    //This while loop will stop once the seninel value is reached
    cin>>transaction_account>>transaction_code>>amount_disk_change;
    line++;
  }
}

bool isValidAccountNumber(int account_number){
  /*
    This function checks if the account is valid by checking if it consists of 6 digits and that the leftmost digits equals the units digit of the sum of the other digits, each multiplied by its position.
   */
  int count=0;
  int sum=0;
  int first_digit=0;

  while (account_number>0){

    int digit=account_number%10;//gives the last digit

    count++;//keeps track of the number of digits in account_number

    if(count==6){
      first_digit=digit;//saving the left digit
    }else{
      sum+=(digit*count);//multiplying digit by position
    }

    account_number /=10;//removes the last digit
  }

  return (count==6 && (sum%10==first_digit));
}

void calculateBill(double base_charge, double disk_limit, double max_disk_usage, double end_disk_used, double &over_limit_surcharge, double &end_surcharge, double &GST_owed, double &total_owed){
  /*
    Calculates the bill for the transaction by calculating the over limit surcharge, end surcharge, GST owed, and total owed.
   */

  double over_limit= max_disk_usage-disk_limit;

  if(over_limit<=0){
    over_limit_surcharge=0;
  }
  else if(over_limit<=50.0){
    over_limit_surcharge=over_limit*0.15;
  }
  else if(50.0<over_limit && over_limit<=250){
    over_limit_surcharge=50*0.15;
    over_limit-=50;
    over_limit_surcharge+=over_limit*0.26;
  }
  else if(over_limit>250 && over_limit<=500){
    over_limit_surcharge=(50*0.15)+(200*0.26);
    over_limit-=250;
    over_limit_surcharge+=over_limit*0.37;
  }
  else{
    over_limit_surcharge=(50*0.15)+(200*0.26)+(250*0.37);
    over_limit-=500;
    over_limit_surcharge+=over_limit*0.48;
  }

  double over_end_limit= end_disk_used-disk_limit;

  if(over_end_limit>0){
    end_surcharge=over_end_limit*0.05;

    if(end_surcharge<5){
      end_surcharge=5;
    }
  }
  else{
    end_surcharge=0;
  }

  GST_owed=((base_charge+over_limit_surcharge+end_surcharge)*0.05);

  total_owed=base_charge+over_limit_surcharge+end_surcharge+GST_owed;
}

void printBill(int account_number, double base_charge, double disk_limit, double start_disk_usage, double max_disk_usage, double end_disk_used, double over_limit_surcharge, double end_surcharge, double GST_owed, double total_owed){
  /*
    Prints the bill using the values and the disk values are three decimal places while the dollar values are two decimal places. The surcharge is only printed when applied.
   */
  int width=25;//the width space given to a value
  
  cout<<fixed<<setprecision(3)<<left;
  //setting every following value to three digits and left aligned.

  cout<<setw(width)<<"Account Number: "<<account_number<<endl;
  cout<<setw(width)<<"Disk Allotment: "<<disk_limit<<" MB"<<endl;
  cout<<setw(width)<<"Beginning of Month: "<<start_disk_usage<<" MB"<<endl;
  cout<<setw(width)<<"Maximum during Month: "<<max_disk_usage<<" MB"<<endl;
  cout<<setw(width)<<"End of Month: "<<end_disk_used<<" MB"<<endl;

  cout<<fixed<<setprecision(2)<<left;
  //setting the dollar values to two decimal places and left aligned
  cout<<setw(width-1)<<"Base Charge: "<<setw(3)<<"$"<<base_charge<<endl;

  if (over_limit_surcharge > 0){
    cout<<setw(width-1)<<"Over-limit Surcharge: "<<setw(3)<<"$"<<over_limit_surcharge<<endl;
  }

  if (end_surcharge > 0) {
    cout<<setw(width-1)<<"Surcharge: "<<setw(3)<<"$"<<end_surcharge<<endl;
    }

  cout<<setw(width-1)<<"GST: "<<setw(3)<<"$"<<GST_owed<<endl;
  cout<<setw(width-1)<<"Amount Due: "<<setw(3)<<"$"<<total_owed<<endl;
}
