#include "function.h"
#include <iostream>
using namespace std;

int main(){
  /*
    This function reads customer header records until the end of the file. For each customer it calls readAndProcess, then either prints an error message or calculates and prints the bill. Keeps counts of lines, accounts and errors, and prints these numbers onces it finishes processing the transaction.
   */

  //initializing the variables 
  int account_number;
  double base_charge;
  double disk_limit;
  double start_disk_usage;
  double max_disk_usage;
  double end_disk_used;
  bool valid;
  double over_limit_surcharge;
  double end_surcharge;
  double GST_owed;
  double total_owed;
  int error=0;
  int line=0;
  int number_of_accounts=0;

  //This while loop reads till end of the input
  while(cin>>account_number>>base_charge>>disk_limit>>start_disk_usage){
  line++;
  readAndProcess(account_number, start_disk_usage, max_disk_usage, end_disk_used, valid, error, line);
  if(!valid){
    //if not valid it prints an error
    cout<<"*** Account "<<account_number<<" not processed due to errors ***"<<endl;
  }
  else{
    
  calculateBill(base_charge,disk_limit,max_disk_usage,end_disk_used,over_limit_surcharge, end_surcharge, GST_owed, total_owed);

  printBill(account_number,base_charge,disk_limit,start_disk_usage,max_disk_usage,end_disk_used,over_limit_surcharge,end_surcharge,GST_owed,total_owed);

  }

  number_of_accounts++;

  }

  cout<<"Processed "<<line<<" total lines. Processed "<<number_of_accounts<<" accounts. There were "<<error<<" errors."<<endl;
  
}
