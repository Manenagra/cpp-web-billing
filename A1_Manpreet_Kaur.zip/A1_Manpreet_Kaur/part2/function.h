#ifndef FUNCTION_H
#define FUNCTION_H

void readAndProcess(int account_number, double start_disk_usage, double &max_disk_usage, double &end_disk_used, bool &valid, int &error, int &line);

void readAndTotal(int account_number, double start_disk_usage, double &max_disk_usage, double &end_disk_used, bool &valid, int &line, int &error);

void readAndIgnore(int &line);

bool isValidAccountNumber(int account_number);

void calculateBill(double base_charge, double disk_limit, double max_disk_usage, double end_disk_used, double &over_limit_surcharge, double &end_surcharge, double &GST_owed, double &total_owed);

void printBill(int account_number, double base_charge, double disk_limit, double start_disk_usage, double max_disk_usage, double end_disk_used, double over_limit_surcharge, double end_surcharge, double GST_owed, double total_owed);

#endif
